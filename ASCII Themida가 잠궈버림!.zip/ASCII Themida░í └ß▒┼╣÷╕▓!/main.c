#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  for(;;){
          int c=getche();
          printf("\n%c %d 0x%x\n",c,c,c);
  }
  system("PAUSE");	
  return 0;
}
