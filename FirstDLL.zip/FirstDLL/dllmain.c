/* Replace "dll.h" with the name of your header */
#include "dll.h"
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>

DLLIMPORT int HelloWorld (int x, int y)
{
    MessageBox (0, "Hello World from DLL!\n", "Hi", MB_ICONINFORMATION);
    return x+y;
}


BOOL APIENTRY DllMain (HINSTANCE hInst     /* Library instance handle. */ ,
                       DWORD reason        /* Reason this function is being called. */ ,
                       LPVOID reserved     /* Not used. */ )
{
    switch (reason)
    {
      case DLL_PROCESS_ATTACH:
          MessageBox (0, "ATTATCH!\n", "Hi", MB_ICONINFORMATION);
        break;

      case DLL_PROCESS_DETACH:
          MessageBox (0, "DETACH!\n", "Hi", MB_ICONINFORMATION);
        break;

      case DLL_THREAD_ATTACH:
          MessageBox (0, "THREAD ATTATCH!\n", "Hi", MB_ICONINFORMATION);
        break;

      case DLL_THREAD_DETACH:
          MessageBox (0, "THREAD DETACH!\n", "Hi", MB_ICONINFORMATION);
        break;
    }

    /* Returns TRUE on success, FALSE on failure */
    return TRUE;
}
