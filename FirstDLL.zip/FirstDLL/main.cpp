#include "dll.h"
#include <windows.h>
#include <stdio.h>

int main(){
    int result;
    HINSTANCE hInst;
    int (*pFunc)(int,int);
    hInst=LoadLibrary("dll.dll");
    if (hInst == NULL) return 0;
    pFunc=(int(*)(int,int))GetProcAddress(hInst, "HelloWorld");
    result=(*pFunc)(3,4);
    printf("The Result of is %d", result);
    FreeLibrary(hInst);
    return 0;
}
